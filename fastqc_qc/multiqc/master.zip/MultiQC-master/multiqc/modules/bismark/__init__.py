from __future__ import absolute_import

from .bismark import MultiqcModule
