from __future__ import absolute_import

from .salmon import MultiqcModule
