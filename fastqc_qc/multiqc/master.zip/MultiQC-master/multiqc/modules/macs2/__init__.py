from __future__ import absolute_import

from .macs2 import MultiqcModule
